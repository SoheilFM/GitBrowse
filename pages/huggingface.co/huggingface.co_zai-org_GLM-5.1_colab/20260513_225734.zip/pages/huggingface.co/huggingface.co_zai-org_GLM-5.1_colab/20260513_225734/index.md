# Browser capture: https://colab.research.google.com/#fileId=https%3A//huggingface.co/zai-org/GLM-5.1.ipynb

- **Requested URL:** `https://huggingface.co/zai-org/GLM-5.1/colab`
- **Final URL:** `https://colab.research.google.com/#fileId=https%3A//huggingface.co/zai-org/GLM-5.1.ipynb`
- **Time UTC:** `2026-05-13T22:57:34.087056+00:00`
- **Domain:** `huggingface.co`

## Screenshot

![Screenshot](./screenshot.png)

## Offline files

- [Offline HTML](./offline/index.html) ✅
- [MHTML snapshot](./offline/page.mhtml) ✅
- [Original final DOM before rewrite](./offline/final_dom_before_rewrite.html)
- [Offline asset report](./offline/assets.md)

## Page source and links

- [Final DOM](./source/final_dom.html)
- [Visible text](./source/visible_text.txt)
- [All DOM links](./source/all_links.txt)
- [Media/document links](./source/media_links.txt)

## Network / Ajax log

- [Network summary](./network/network.md) ✅
- [Full JSON](./network/network.json)
- [JSONL](./network/network.jsonl)
- Response bodies, when available, are saved in `network/bodies/`.

## Automation and session

- [Automation log](./automation-log.json) ✅
- Session state: `sessions/huggingface_co.json`

## Proxy

- Mode: `none`

## Stats

- Network requests: `65`
- Offline assets saved: `183`
- Offline assets skipped: `0`
- Offline assets failed: `9`
